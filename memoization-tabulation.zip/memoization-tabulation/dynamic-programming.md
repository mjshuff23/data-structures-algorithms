# Dynamic Programming Tips

- Notice any overlapping subproblems
- Decide on trivial smallest input ('', 0, [])
- Use brute force if necessary to get it working
- think recursively and use Memoization
- think iteratively and use Tabulation
- draw a strategy
