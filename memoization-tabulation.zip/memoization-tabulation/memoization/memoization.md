# Memoization Recipe

1. Make it work
   1. Visualive problem as a tree
   2. Implement tree using recursion
   3. Test it
2. Make it efficient
   1. Add memo object
   2. Add base case to return memo values (memo fetching)
   3. Store return value in memo